This zip experiment does not contain an experiment folder: the ImportExperiment service should throw an exception.
